#include <stdio.h> // Incluye la biblioteca estándar de entrada y salida

// Función principal del programa
int main(){
    FILE *fd; // Declara un puntero a FILE para manejar el archivo
    char c; // Declara una variable para almacenar un carácter leído del archivo

    char *filename = "archw.txt"; // Declara el nombre del archivo
    fd = fopen(filename, "r"); // Abre el archivo en modo lectura ("r") y asigna el puntero a fd
    if(fd == NULL){ // Verifica si la apertura del archivo falló
        printf("No se pudo abrir el archivo %s\n", filename); // Si falló, imprime un mensaje de error
        return 1; // Sale del programa con un código de error
    }

    c = fgetc(fd); // Lee el primer carácter del archivo
    while (c != EOF) // Bucle que se ejecuta hasta alcanzar el final del archivo (EOF)
    {
        putchar(c); // Imprime el carácter leído en la consola
        c = fgetc(fd); // Lee el siguiente carácter del archivo
    }

    fclose(fd); // Cierra el archivo
    return 0; // Termina el programa
}


