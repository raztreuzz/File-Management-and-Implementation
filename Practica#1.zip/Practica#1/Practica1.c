#include <stdio.h>
#include <string.h>

// Función principal del programa
int main()
{
    FILE *fd; // Declara un puntero a FILE para manejar el archivo
    char *cadena = "Hola desde c"; // Declara una cadena de caracteres a escribir en el archivo

    char *filename = "archw.txt"; // Declara el nombre del archivo
    fd = fopen(filename, "w"); // Abre el archivo en modo escritura ("w") y asigna el puntero a fd
    if (fd == NULL) // Verifica si la apertura del archivo falló
    {
        printf("No se pudo abrir el archivo %s\n", filename); // Si falló, imprime un mensaje de error
        return 1; // Sale del programa con un código de error
    }
    printf("Archivo %s creado \n", filename); // Imprime un mensaje indicando que el archivo se creó correctamente

    int l = strlen(cadena); // Obtiene la longitud de la cadena a escribir
    int i; // Declara una variable para el ciclo
    for (i = 0; i < l; i++) // Itera sobre cada carácter de la cadena
    {
        fputc(cadena[i], fd); // Escribe cada carácter en el archivo
    }
    fputc('\n', fd); // Escribe un carácter de nueva línea al final de la cadena

    printf("Datos escritos \n"); // Imprime un mensaje indicando que los datos fueron escritos

    fclose(fd); // Cierra el archivo
    return 0; // Termina el programa
}
