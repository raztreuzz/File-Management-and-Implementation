#include <stdio.h> // Incluye la biblioteca estándar de entrada y salida

// Función principal del programa
int main(){
    FILE *fd; // Declara un puntero a FILE para manejar el archivo
    char *filename = "number.dat"; // Declara el nombre del archivo
    fd = fopen(filename, "w+"); // Abre el archivo en modo lectura/escritura ("w+"), crea el archivo si no existe
    if (fd == NULL) // Verifica si la apertura del archivo falló
    {
        printf("No se pudo abrir el archivo %s\n", filename); // Si falló, imprime un mensaje de error
        return 1; // Sale del programa con un código de error
    }
    printf("Archivo %s creado\n", filename); // Imprime un mensaje indicando que el archivo se creó correctamente

    int tamInt = sizeof(int); // Obtiene el tamaño en bytes de un entero (int)
    int i; // Declara una variable para el ciclo
    for (i = 0; i < 10; i++) // Itera de 0 a 9
    {
        fwrite(&i, tamInt, 1, fd); // Escribe el valor de 'i' en el archivo, 'tamInt' bytes, 1 vez
    }
    printf("Números guardados\n"); // Imprime un mensaje indicando que los números fueron guardados

    fclose(fd); // Cierra el archivo

    return 0; // Termina el programa
}


