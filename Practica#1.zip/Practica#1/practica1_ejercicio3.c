#include <stdio.h>

void openFile(const char *filename, const char *mode) {
    FILE *file = fopen(filename, mode);
    if (file == NULL) {
        printf("Error al abrir el archivo '%s'\n", filename);
    } else {
        printf("Archivo '%s' abierto correctamente en modo '%s'\n", filename, mode);
        fclose(file);
    }
}

int main() {
    int choice;
    char filename[100];
    const char *modes[] = {"r", "w", "a", "r+", "w+", "a+"};

    printf("=== Administrador de métodos fopen ===\n");
    printf("1. Abrir archivo en modo lectura (r)\n");
    printf("2. Abrir archivo en modo escritura (w)\n");
    printf("3. Abrir archivo en modo anexar (a)\n");
    printf("4. Abrir archivo en modo lectura y escritura (r+)\n");
    printf("5. Abrir archivo en modo lectura y escritura (w+)\n");
    printf("6. Abrir archivo en modo lectura y anexar (a+)\n");

    printf("Ingrese su elección (1-6): ");
    scanf("%d", &choice);

    if (choice < 1 || choice > 6) {
        printf("Elección inválida. Saliendo...\n");
        return 1;
    }

    printf("Ingrese el nombre del archivo: ");
    scanf("%s", filename);

    openFile(filename, modes[choice - 1]);

    return 0;
}
